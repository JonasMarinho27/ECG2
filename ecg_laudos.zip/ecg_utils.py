import cv2
import numpy as np
from PIL import Image
from ecg_segmentador import extrair_derivacoes
from ecg_analisador import inverter_para_sinal, detectar_picos, calcular_intervalo_rr
from medidas import detectar_limites_qrs, calcular_duracao_intervalo
from intervalos import calcular_intervalo_pr, calcular_intervalo_qt

def carregar_imagem(caminho):
    imagem = cv2.imread(caminho)
    if imagem is None:
        imagem = np.array(Image.open(caminho).convert('RGB'))[..., ::-1]
    return imagem

def processar_ecg(caminho):
    imagem = carregar_imagem(caminho)
    derivacoes = extrair_derivacoes(imagem)
    derivacao = derivacoes[0]

    sinal = inverter_para_sinal(derivacao)
    picos = detectar_picos(sinal)
    rr, fc = calcular_intervalo_rr(picos)
    limites = detectar_limites_qrs(sinal, picos)
    dur_qrs = calcular_duracao_intervalo(limites)
    pr = calcular_intervalo_pr(picos, limites)
    qt = calcular_intervalo_qt(picos, limites)

    return {
        'freq_cardiaca': round(fc, 1),
        'rr': round(rr, 2),
        'qrs': round(dur_qrs, 1),
        'pr': round(pr, 1),
        'qt': round(qt, 1)
    }