def calcular_intervalo_pr(picos, limites, amostragem=40):
    if not picos or not limites or len(picos) < 1:
        return 0
    primeiro_pico = picos[0]
    inicio_qrs = limites[0][0]
    pr = (inicio_qrs - 20) / amostragem * 1000
    return pr if pr > 0 else 0

def calcular_intervalo_qt(picos, limites, amostragem=40):
    if len(limites) < 1 or len(picos) < 1:
        return 0
    inicio = limites[0][0]
    fim = limites[0][1] + 40
    qt = (fim - inicio) / amostragem * 1000
    return qt