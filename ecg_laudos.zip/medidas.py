import numpy as np

def detectar_limites_qrs(sinal, picos, largura=15):
    limites = []
    for pico in picos:
        inicio = pico
        fim = pico
        for i in range(pico, max(pico - largura, 0), -1):
            if sinal[i] < 10:
                inicio = i
                break
        for i in range(pico, min(pico + largura, len(sinal))):
            if sinal[i] < 10:
                fim = i
                break
        limites.append((inicio, fim))
    return limites

def calcular_duracao_intervalo(limites, amostragem=40):
    duracoes = []
    for inicio, fim in limites:
        dur = (fim - inicio) / amostragem * 1000
        duracoes.append(dur)
    return np.mean(duracoes) if duracoes else 0