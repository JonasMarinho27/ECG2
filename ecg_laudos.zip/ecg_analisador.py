import cv2
import numpy as np
from scipy.signal import find_peaks

def inverter_para_sinal(segmento):
    cinza = cv2.cvtColor(segmento, cv2.COLOR_BGR2GRAY)
    linha_meio = cinza.shape[0] // 2
    sinal = 255 - cinza[linha_meio, :]
    return sinal

def detectar_picos(sinal, distancia_minima=40, altura_minima=30):
    picos, _ = find_peaks(sinal, distance=distancia_minima, height=altura_minima)
    return picos

def calcular_intervalo_rr(picos, amostragem=40):
    if len(picos) < 2:
        return 0, 0
    diffs = np.diff(picos)
    rr_medio = np.mean(diffs) / amostragem
    fc = 60 / rr_medio if rr_medio > 0 else 0
    return rr_medio, fc