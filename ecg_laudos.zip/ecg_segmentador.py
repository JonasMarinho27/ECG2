import cv2

def extrair_derivacoes(imagem, num_linhas=3, num_colunas=4):
    altura, largura = imagem.shape[:2]
    altura_segmento = altura // num_linhas
    largura_segmento = largura // num_colunas
    segmentos = []
    for i in range(num_linhas):
        for j in range(num_colunas):
            y_inicio = i * altura_segmento
            x_inicio = j * largura_segmento
            segmento = imagem[y_inicio:y_inicio + altura_segmento, x_inicio:x_inicio + largura_segmento]
            segmentos.append(segmento)
    return segmentos