from flask import Flask, render_template, request, send_file
from ecg_utils import processar_ecg
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    resultado = None
    if request.method == 'POST':
        file = request.files['arquivo']
        if file:
            caminho = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(caminho)
            resultado = processar_ecg(caminho)
    return render_template('index.html', resultado=resultado)

if __name__ == '__main__':
    app.run(debug=True)